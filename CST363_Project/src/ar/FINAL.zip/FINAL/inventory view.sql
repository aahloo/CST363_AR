USE invetorydb;
-- CREATE AN INVENTORY VIEW	
-- get total inventory of all products
-- along with the catagory description for each
CREATE VIEW all_inventory AS
SELECT parts_part_name AS Part, sum(bin_qty) AS Qty,
	catagory_description AS Catagory
FROM inventory_bins
JOIN parts
ON parts_part_name = part_name
JOIN part_catagories
ON part_catagories_catagory_id = catagory_id
GROUP BY parts_part_name
ORDER BY 1;