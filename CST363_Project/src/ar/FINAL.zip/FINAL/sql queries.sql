-- get part name and desc from all buy outs and manufactured parts only,
-- sort by part catagory, then by part name
SELECT part_name, part_description
FROM parts
WHERE part_catagories_catagory_id = 0
	OR part_catagories_catagory_id = 1
ORDER BY part_catagories_catagory_id, part_name;

-- get all parts that have an inventory of greater than 1
-- select part_name, part_description, bin_id, and bin_qty
-- sort by bin_qty desc
SELECT part_name, part_description, bin_id, bin_qty
FROM parts
JOIN inventory_bins
ON parts.part_name = inventory_bins.parts_part_name
WHERE inventory_bins.bin_qty > 0
ORDER BY inventory_bins.bin_qty desc;

-- get all bins for an item
-- ex: Cool Part
SELECT parts_part_name, bin_id, bin_qty
FROM inventory_bins
WHERE parts_part_name = 'Cool Part';

-- get total inventory of all products
-- along with the catagory description for each
SELECT parts_part_name AS Part, sum(bin_qty) AS Qty,
	catagory_description AS Catagory
FROM inventory_bins
JOIN parts
ON parts_part_name = part_name
JOIN part_catagories
ON part_catagories_catagory_id = catagory_id
GROUP BY parts_part_name
ORDER BY 1;

-- update inventory
-- ex: add 100pcs O-Ring 1343
UPDATE inventory_bins
SET bin_qty = bin_qty + 100
WHERE parts_part_name = 'O-Ring 1343';