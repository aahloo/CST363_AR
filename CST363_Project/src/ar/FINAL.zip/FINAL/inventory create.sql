DROP SCHEMA IF EXISTS inventorydb;
CREATE SCHEMA inventorydb;
USE inventorydb;

CREATE  TABLE part_catagories(
	catagory_id	VARCHAR(6) NOT NULL,
	catagory_description	VARCHAR(45) NULL,
	CONSTRAINT	part_catagories_PK	PRIMARY KEY(catagory_id)
	);

CREATE  TABLE parts(
	part_name VARCHAR(30) NOT NULL,
	part_description VARCHAR(45) NULL,
	part_catagories_catagory_id VARCHAR(6) NOT NULL,
	CONSTRAINT 	parts_PK	PRIMARY KEY(part_name),
	CONSTRAINT parts_part_catagory_FK	FOREIGN KEY (part_catagories_catagory_id)
		REFERENCES part_catagories(catagory_id)
			ON DELETE NO ACTION
			ON UPDATE NO ACTION
	);


CREATE  TABLE inventory_bins(
	bin_id			Int				AUTO_INCREMENT,
	bin_qty			decimal(8,2)	NULL,
	parts_part_name VarChar(30) NOT NULL,
	CONSTRAINT inventory_bins_PK	PRIMARY KEY(bin_id),
    CONSTRAINT i_b_parts_FK	FOREIGN KEY(parts_part_name)
							REFERENCES parts(part_name)
								ON UPDATE NO ACTION
								ON DELETE NO ACTION
	);


