USE inventorydb;

/*****   part_catagories DATA   ********************************************************/

INSERT INTO part_catagories VALUES(
	0, 'Buy Out');
INSERT INTO part_catagories VALUES(
	1, 'Manufactured');
INSERT INTO part_catagories VALUES(
	2, 'Material');
INSERT INTO part_catagories VALUES(
	3, 'Tool');
INSERT INTO part_catagories VALUES(
	4, 'Other');
    
/*****   parts DATA   **************************************************************/

INSERT INTO parts VALUES(
	'Screw Driver #2', 'Phillips Head #2 Screw Driver', 3);
INSERT INTO parts VALUES(
	'Screw Driver #1', 'Phillips Head #1 Screw Driver', 3);
INSERT INTO parts VALUES(
	'O-Ring 183', '3" ID x 4" OD O-Ring', 0);
INSERT INTO parts VALUES(
	'O-Ring 1763', '4" ID x 5" OD O-Ring', 0);
INSERT INTO parts VALUES(
	'O-Ring 1863', '1" ID x 2" OD O-Ring', 0);
INSERT INTO parts VALUES(
	'O-Ring 1342', '1" ID x 4" OD O-Ring', 0);
INSERT INTO parts VALUES(
	'O-Ring 1343', '1" ID x 6" OD O-Ring', 0);
INSERT INTO parts VALUES(
	'Cool Part', 'This is a Cool Part!', 1);
INSERT INTO parts VALUES(
	'Awesome Part', 'This is an Awesome Part!', 1);
INSERT INTO parts VALUES(
	'Sweet Part', 'This is a Sweet Part!', 1);


/*****   inventory_bins DATA   ************************************************/

INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(15, 'Awesome Part');
INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(10, 'O-Ring 1343');
INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(12.2, 'Cool Part');
INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(1560, 'O-Ring 1763');
INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(14565, 'Screw Driver #1');
INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(205, 'O-Ring 1863');
INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(16, 'O-Ring 1342');
INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(95, 'O-Ring 183');
INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(15, 'Screw Driver #2');
INSERT INTO inventory_bins (bin_qty, parts_part_name)
	VALUES(901, 'Sweet Part');